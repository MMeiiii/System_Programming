#include <stdio.h>
#include "apue.h"

void accumulation(int d_sum);

int main()
{
	FILE* sum;
	int total_sum=0;
	pid_t pid[6];
	int year=5, week=52, day=7;
	char filename[50];
	FILE* text;

	sum = fopen("sum.txt", "w");
	fprintf(sum, "%d\n", 0);
	fclose(sum);

	/**********************************************************/
		
	//Implement your code.
	for(int i = 1; i <= year; i ++){
	
		TELL_WAIT();
		if( (pid[i] = fork()) < 0){
			err_sys("fork error\n");
			exit(0);
		}
		else if( pid[i] == 0){
			for(int j = 1; j <= week; j ++){
				sprintf(filename, "%d-%02d.txt", i, j);
				text = fopen(filename, "r");
				for(int k = 1; k <= day; k ++){
					int temp = 0;
					for(int l = 1; l <= 96; l ++){
						int value;
						fscanf(text, "%d", &value);
						temp += value;
					}
					WAIT_PARENT();
					accumulation(temp);
					TELL_PARENT(getppid());
				}	
			}
			exit(0);		
		}
		else{
			for(int i = 1; i <= week; i ++){
				for(int j = 1; j <= day; j ++){
					TELL_CHILD(pid[i]);
					WAIT_CHILD();
				}
			}
		}	
	}
	
	/**********************************************************/

	sum = fopen("sum.txt", "r");
	fscanf(sum, "%d", &total_sum);
	printf("Day_Average = %d\n",total_sum/(year*week*day));
	fclose(sum);

	return 0;
}

void accumulation(int d_sum)    //Accumulating the daily sum to "sum.txt".
{
	FILE* sum;
	int tmp=0;

	sum = fopen("sum.txt", "r+");
	fscanf(sum, "%d", &tmp);

	tmp += d_sum;

	rewind(sum);
	fprintf(sum, "%d", tmp);
	fclose(sum);

	return;
}
